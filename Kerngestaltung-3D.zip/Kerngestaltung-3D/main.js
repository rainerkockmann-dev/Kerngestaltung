import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { Line2 } from 'three/addons/lines/Line2.js';
import { LineGeometry } from 'three/addons/lines/LineGeometry.js';
import { LineMaterial } from 'three/addons/lines/LineMaterial.js';

const canvas = document.querySelector('#scene');
const panel = document.querySelector('#panel');

const SETTINGS = {
  speed: 1.15,
  spawnInterval: 2.8,
  organicNoise: 0.9,
  lineAttraction: 0.045,
  nodeAttraction: 0.12,
  intersectionDistance: 0.42,
  myceliumGrowth: 0.85,
  maxLines: 52,
  autoSpawn: true,
  showFields: true,
};

const WORLD = new THREE.Vector3(28, 18, 20);
const HALF = WORLD.clone().multiplyScalar(0.5);
const HASH_CELL = 1.35;
const MAX_POINTS_PER_STROKE = 260;
const PAPER = new THREE.Color(0xeee4cc);
const CHARCOAL = new THREE.Color(0x342f28);
const WARM_LIGHT = new THREE.Color(0xffefbd);

const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: true,
  alpha: true,
  powerPreference: 'high-performance',
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight, false);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;

const scene = new THREE.Scene();
scene.background = PAPER;
scene.fog = new THREE.FogExp2(PAPER, 0.018);

const camera = new THREE.PerspectiveCamera(46, window.innerWidth / window.innerHeight, 0.1, 180);
camera.position.set(0, 2.2, 28);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.055;
controls.minDistance = 8;
controls.maxDistance = 62;
controls.target.set(0, 0, 0);
controls.update();

const worldGroup = new THREE.Group();
scene.add(worldGroup);

const lineMaterials = new Set();
const tempV1 = new THREE.Vector3();
const tempV2 = new THREE.Vector3();
const tempV3 = new THREE.Vector3();
const tempV4 = new THREE.Vector3();

let paused = false;
let elapsed = 0;
let spawnAccumulator = 0;
let frame = 0;
let strokeId = 0;
let lastStatsUpdate = 0;
let resetTimers = [];

const system = {
  strokes: [],
  strokeMap: new Map(),
  nodes: [],
  filaments: [],
  segmentHash: new Map(),
  segmentCount: 0,
  lastHashRebuild: 0,
};

function rand(min = 0, max = 1) {
  return min + Math.random() * (max - min);
}

function randomUnitVector() {
  const z = rand(-1, 1);
  const a = rand(0, Math.PI * 2);
  const r = Math.sqrt(1 - z * z);
  return new THREE.Vector3(r * Math.cos(a), r * Math.sin(a), z);
}

function randomPointInWorld(margin = 0.82) {
  return new THREE.Vector3(
    rand(-HALF.x * margin, HALF.x * margin),
    rand(-HALF.y * margin, HALF.y * margin),
    rand(-HALF.z * margin, HALF.z * margin),
  );
}

function randomDistantPoint(origin) {
  let target = randomPointInWorld(0.9);
  for (let i = 0; i < 16 && target.distanceTo(origin) < 9; i += 1) {
    target = randomPointInWorld(0.9);
  }
  return target;
}

function flowField(position, time, seed) {
  const s = seed * 0.37;
  const x = Math.sin(position.y * 0.43 + time * 0.31 + s) - Math.cos(position.z * 0.29 - time * 0.23 + s * 1.7);
  const y = Math.sin(position.z * 0.39 - time * 0.27 + s * 2.1) - Math.cos(position.x * 0.33 + time * 0.19 - s);
  const z = Math.sin(position.x * 0.35 + time * 0.21 - s * 1.3) - Math.cos(position.y * 0.31 - time * 0.17 + s * 0.7);
  return new THREE.Vector3(x, y, z).normalize();
}

function makeRadialTexture(inner = 'rgba(255,247,208,0.94)', outer = 'rgba(255,234,165,0)') {
  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 128;
  const ctx = c.getContext('2d');
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, inner);
  g.addColorStop(0.16, 'rgba(255,244,200,0.44)');
  g.addColorStop(0.48, 'rgba(255,237,178,0.11)');
  g.addColorStop(1, outer);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}

function makeCharcoalDotTexture() {
  const c = document.createElement('canvas');
  c.width = 64;
  c.height = 64;
  const ctx = c.getContext('2d');
  const g = ctx.createRadialGradient(32, 32, 2, 32, 32, 31);
  g.addColorStop(0, 'rgba(44,38,31,.86)');
  g.addColorStop(.25, 'rgba(55,47,38,.50)');
  g.addColorStop(.7, 'rgba(55,47,38,.12)');
  g.addColorStop(1, 'rgba(55,47,38,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}

const glowTexture = makeRadialTexture();
const charcoalTexture = makeCharcoalDotTexture();

function addWorldFrame() {
  const geometry = new THREE.EdgesGeometry(new THREE.BoxGeometry(WORLD.x, WORLD.y, WORLD.z));
  const material = new THREE.LineBasicMaterial({
    color: 0x6f6456,
    transparent: true,
    opacity: 0.055,
  });
  const frameObject = new THREE.LineSegments(geometry, material);
  worldGroup.add(frameObject);
}

function addAmbientDust() {
  const count = 520;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i += 1) {
    positions[i * 3] = rand(-HALF.x * 1.1, HALF.x * 1.1);
    positions[i * 3 + 1] = rand(-HALF.y * 1.1, HALF.y * 1.1);
    positions[i * 3 + 2] = rand(-HALF.z * 1.1, HALF.z * 1.1);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const material = new THREE.PointsMaterial({
    color: 0x6b604f,
    size: 0.028,
    transparent: true,
    opacity: 0.18,
    depthWrite: false,
  });
  const dust = new THREE.Points(geometry, material);
  dust.name = 'ambient-dust';
  worldGroup.add(dust);
}

class OrganicStroke {
  constructor() {
    this.id = ++strokeId;
    this.seed = rand(0, 1000);
    this.age = 0;
    this.maxAge = rand(32, 70);
    this.active = true;
    this.expired = false;
    this.opacity = rand(0.57, 0.82);
    this.baseOpacity = this.opacity;
    this.pointSpacing = rand(0.19, 0.34);
    this.position = randomPointInWorld(0.72);
    this.target = randomDistantPoint(this.position);
    this.velocity = this.target.clone().sub(this.position).normalize().multiplyScalar(rand(0.65, 1.1));
    this.points = [this.position.clone()];
    this.outsideTime = 0;
    this.escapeDrift = randomUnitVector().multiplyScalar(rand(0.1, 0.35));
    this.lastAddedPoint = this.position.clone();
    this.group = new THREE.Group();
    this.group.userData.strokeId = this.id;

    this.mainGeometry = new LineGeometry();
    this.mainGeometry.setPositions([
      this.position.x, this.position.y, this.position.z,
      this.position.x + 0.001, this.position.y, this.position.z,
    ]);
    this.mainMaterial = new LineMaterial({
      color: CHARCOAL,
      linewidth: rand(0.85, 1.65),
      transparent: true,
      opacity: this.opacity,
      depthWrite: false,
      worldUnits: false,
    });
    this.mainLine = new Line2(this.mainGeometry, this.mainMaterial);
    this.mainLine.computeLineDistances();
    this.mainLine.renderOrder = 2;
    this.mainLine.frustumCulled = false;
    this.group.add(this.mainLine);
    lineMaterials.add(this.mainMaterial);

    this.fieldGeometry = new LineGeometry();
    this.fieldGeometry.setPositions([
      this.position.x, this.position.y, this.position.z,
      this.position.x + 0.001, this.position.y, this.position.z,
    ]);
    this.fieldMaterial = new LineMaterial({
      color: 0xffeab0,
      linewidth: rand(8, 15),
      transparent: true,
      opacity: 0.01,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      worldUnits: false,
    });
    this.fieldLine = new Line2(this.fieldGeometry, this.fieldMaterial);
    this.fieldLine.renderOrder = 0;
    this.fieldLine.frustumCulled = false;
    this.group.add(this.fieldLine);
    lineMaterials.add(this.fieldMaterial);

    this.ghosts = [];
    for (let i = 0; i < 3; i += 1) {
      const geometry = new THREE.BufferGeometry().setFromPoints(this.points);
      const material = new THREE.LineBasicMaterial({
        color: i === 0 ? 0x4b4236 : 0x2d2923,
        transparent: true,
        opacity: this.opacity * rand(0.08, 0.18),
        depthWrite: false,
      });
      const line = new THREE.Line(geometry, material);
      line.userData.strand = i;
      this.ghosts.push(line);
      this.group.add(line);
    }

    this.dustGeometry = new THREE.BufferGeometry();
    this.dustMaterial = new THREE.PointsMaterial({
      color: 0x443a30,
      size: rand(0.05, 0.09),
      map: charcoalTexture,
      transparent: true,
      opacity: this.opacity * 0.17,
      alphaTest: 0.015,
      depthWrite: false,
      sizeAttenuation: true,
    });
    this.dust = new THREE.Points(this.dustGeometry, this.dustMaterial);
    this.group.add(this.dust);

    worldGroup.add(this.group);
  }

  update(dt) {
    this.age += dt;
    if (!this.active) return;

    const lineForce = computeStrokeForce(this);
    const flow = flowField(this.position, elapsed, this.seed).multiplyScalar(SETTINGS.organicNoise * 0.62);
    const targetDirection = this.target.clone().sub(this.position);
    const targetDistance = targetDirection.length();

    if (targetDistance < rand(1.0, 2.4)) {
      this.target.copy(randomDistantPoint(this.position));
    }

    targetDirection.normalize().multiplyScalar(0.3);
    const acceleration = targetDirection.add(flow).add(lineForce);

    const collectiveDrag = Math.max(0.91, 0.975 - system.strokes.length * 0.00015);
    this.velocity.multiplyScalar(Math.pow(collectiveDrag, dt * 60));
    this.velocity.addScaledVector(acceleration, dt);

    const desiredSpeed = SETTINGS.speed * rand(0.92, 1.08);
    const currentSpeed = this.velocity.length();
    if (currentSpeed < desiredSpeed * 0.58) this.velocity.setLength(desiredSpeed * 0.58);
    if (currentSpeed > desiredSpeed * 1.34) this.velocity.setLength(desiredSpeed * 1.34);

    const outside = outsideDistance(this.position);
    if (outside > 0) {
      this.outsideTime += dt;
      this.velocity.addScaledVector(this.escapeDrift, dt * (0.7 + outside * 0.12));
      this.opacity = this.baseOpacity * Math.exp(-outside * 0.68 - this.outsideTime * 0.34);
      if (outside > 5.8 || this.opacity < 0.018) {
        this.active = false;
        this.expired = true;
      }
    } else {
      this.outsideTime = 0;
      this.opacity += (this.baseOpacity - this.opacity) * Math.min(1, dt * 2);
    }

    this.position.addScaledVector(this.velocity, dt);

    if (this.position.distanceToSquared(this.lastAddedPoint) >= this.pointSpacing * this.pointSpacing) {
      const a = this.lastAddedPoint.clone();
      const b = this.position.clone();
      this.points.push(b);
      this.lastAddedPoint.copy(b);
      this.refreshGeometry();
      registerSegment(this, a, b);
    }

    if (this.points.length >= MAX_POINTS_PER_STROKE || this.age > this.maxAge) {
      this.active = false;
    }

    this.updateVisualStrength();
  }

  refreshGeometry() {
    const flat = new Float32Array(this.points.length * 3);
    const ghostPoints = [[], [], []];
    const dustPoints = [];

    for (let i = 0; i < this.points.length; i += 1) {
      const p = this.points[i];
      flat[i * 3] = p.x;
      flat[i * 3 + 1] = p.y;
      flat[i * 3 + 2] = p.z;

      for (let s = 0; s < 3; s += 1) {
        const amp = 0.018 + s * 0.012;
        const wave = Math.sin(i * (1.27 + s * 0.13) + this.seed * (0.08 + s * 0.03));
        const wave2 = Math.cos(i * (0.93 + s * 0.19) - this.seed * 0.04);
        ghostPoints[s].push(new THREE.Vector3(
          p.x + wave * amp,
          p.y + wave2 * amp,
          p.z + (wave - wave2) * amp * 0.72,
        ));
      }

      if (i % 3 === 0 && Math.sin(i * 3.17 + this.seed) > -0.15) {
        const scatter = 0.045 + 0.018 * Math.sin(i * 0.71 + this.seed);
        dustPoints.push(new THREE.Vector3(
          p.x + Math.sin(i * 1.91 + this.seed) * scatter,
          p.y + Math.cos(i * 1.37 - this.seed) * scatter,
          p.z + Math.sin(i * 1.13 + this.seed * 2) * scatter,
        ));
      }
    }

    this.mainGeometry.setPositions(flat);
    this.fieldGeometry.setPositions(flat);
    for (let s = 0; s < 3; s += 1) {
      this.ghosts[s].geometry.dispose();
      this.ghosts[s].geometry = new THREE.BufferGeometry().setFromPoints(ghostPoints[s]);
    }
    this.dustGeometry.dispose();
    this.dustGeometry = new THREE.BufferGeometry().setFromPoints(dustPoints);
    this.dust.geometry = this.dustGeometry;
  }

  updateVisualStrength() {
    const collective = 1 + Math.log1p(system.strokes.length) * 0.22;
    this.mainMaterial.opacity = this.opacity;
    this.fieldMaterial.opacity = SETTINGS.showFields
      ? this.opacity * Math.min(0.085, 0.004 + system.strokes.length * 0.0008) * collective
      : 0;
    for (let i = 0; i < this.ghosts.length; i += 1) {
      this.ghosts[i].material.opacity = this.opacity * (0.075 + i * 0.025);
    }
    this.dustMaterial.opacity = this.opacity * 0.16;
  }

  dispose() {
    worldGroup.remove(this.group);
    this.mainGeometry.dispose();
    this.mainMaterial.dispose();
    this.fieldGeometry.dispose();
    this.fieldMaterial.dispose();
    lineMaterials.delete(this.mainMaterial);
    lineMaterials.delete(this.fieldMaterial);
    this.ghosts.forEach((line) => {
      line.geometry.dispose();
      line.material.dispose();
    });
    this.dustGeometry.dispose();
    this.dustMaterial.dispose();
  }
}

class CoreNode {
  constructor(position) {
    this.position = position.clone();
    this.strength = 1;
    this.hits = 1;
    this.age = 0;
    this.lastGrowth = -Infinity;
    this.loops = [];
    this.group = new THREE.Group();
    this.group.position.copy(position);
    this.group.rotation.set(rand(-1, 1), rand(-1, 1), rand(-1, 1));

    const coreGeometry = new THREE.IcosahedronGeometry(0.075, 1);
    const coreMaterial = new THREE.MeshBasicMaterial({
      color: 0xfff0bd,
      transparent: true,
      opacity: 0.88,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.core = new THREE.Mesh(coreGeometry, coreMaterial);
    this.group.add(this.core);

    const glowMaterial = new THREE.SpriteMaterial({
      map: glowTexture,
      color: 0xffe9a7,
      transparent: true,
      opacity: 0.32,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.glow = new THREE.Sprite(glowMaterial);
    this.glow.scale.setScalar(1.2);
    this.group.add(this.glow);

    worldGroup.add(this.group);
    this.addLoop();
  }

  absorb(amount = 0.35) {
    this.hits += 1;
    this.strength = Math.min(16, this.strength + amount + this.hits * 0.025);
  }

  addLoop() {
    const count = 46;
    const normal = randomUnitVector();
    const reference = Math.abs(normal.y) < 0.88 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);
    const u = new THREE.Vector3().crossVectors(normal, reference).normalize();
    const v = new THREE.Vector3().crossVectors(normal, u).normalize();
    const radius = rand(0.17, 0.35) + this.loops.length * rand(0.018, 0.034);
    const points = [];

    for (let i = 0; i <= count; i += 1) {
      const t = (i / count) * Math.PI * 2;
      const wobble = 1 + Math.sin(t * rand(2.1, 5.2) + this.hits) * rand(0.035, 0.16);
      const radial = radius * wobble;
      const p = u.clone().multiplyScalar(Math.cos(t) * radial)
        .addScaledVector(v, Math.sin(t) * radial)
        .addScaledVector(normal, Math.sin(t * 3 + this.strength) * radius * 0.12);
      points.push(p);
    }

    const geometry = new THREE.BufferGeometry().setFromPoints(points);
    const material = new THREE.LineBasicMaterial({
      color: this.loops.length % 3 === 0 ? 0xfff0bf : 0xffe4a0,
      transparent: true,
      opacity: rand(0.055, 0.12),
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const loop = new THREE.Line(geometry, material);
    loop.rotation.copy(new THREE.Euler(rand(-0.6, 0.6), rand(-0.6, 0.6), rand(-0.6, 0.6)));
    this.group.add(loop);
    this.loops.push(loop);
  }

  update(dt) {
    this.age += dt;
    const collective = 1 + system.strokes.length * 0.018 + system.nodes.length * 0.035;
    this.strength = Math.min(16, this.strength + dt * SETTINGS.myceliumGrowth * 0.018 * collective);

    const scale = 1 + Math.log1p(this.strength) * 0.32;
    this.core.scale.setScalar(scale);
    this.core.material.opacity = Math.min(0.98, 0.56 + this.strength * 0.035);
    const glowScale = 0.8 + this.strength * 0.16 + Math.sin(elapsed * 1.7 + this.position.x) * 0.06;
    this.glow.scale.setScalar(glowScale);
    this.glow.material.opacity = Math.min(0.68, 0.15 + this.strength * 0.032);

    this.group.rotation.x += dt * 0.019;
    this.group.rotation.y -= dt * 0.013;
    this.group.rotation.z += dt * 0.008;

    const desiredLoops = Math.min(18, 1 + Math.floor(this.strength * 0.92 + this.hits * 0.65));
    if (this.loops.length < desiredLoops && frame % 7 === 0) this.addLoop();

    this.loops.forEach((loop, index) => {
      loop.material.opacity = Math.min(0.24, 0.045 + this.strength * 0.006 + index * 0.0015);
    });

    const growthDelay = Math.max(0.45, 2.35 / Math.max(0.12, SETTINGS.myceliumGrowth));
    if (SETTINGS.myceliumGrowth > 0 && elapsed - this.lastGrowth > growthDelay && this.strength > 1.25) {
      growFilamentFrom(this);
      this.lastGrowth = elapsed + rand(-0.25, 0.45);
    }
  }

  dispose() {
    worldGroup.remove(this.group);
    this.core.geometry.dispose();
    this.core.material.dispose();
    this.glow.material.dispose();
    this.loops.forEach((loop) => {
      loop.geometry.dispose();
      loop.material.dispose();
    });
  }
}

class Filament {
  constructor(sourceNode, target) {
    this.sourceNode = sourceNode;
    this.age = 0;
    this.seed = rand(0, 1000);
    this.baseOpacity = rand(0.09, 0.2);

    const start = sourceNode.position.clone();
    const end = target.clone();
    const delta = end.clone().sub(start);
    const distance = Math.max(0.2, delta.length());
    const sideA = randomUnitVector().multiplyScalar(distance * rand(0.08, 0.24));
    const sideB = randomUnitVector().multiplyScalar(distance * rand(0.05, 0.18));
    const controlA = start.clone().lerp(end, 0.32).add(sideA);
    const controlB = start.clone().lerp(end, 0.7).add(sideB);
    const curve = new THREE.CubicBezierCurve3(start, controlA, controlB, end);
    const points = curve.getPoints(Math.max(12, Math.min(44, Math.round(distance * 5.5))));

    for (let i = 1; i < points.length - 1; i += 1) {
      const taper = Math.sin((i / (points.length - 1)) * Math.PI);
      points[i].addScaledVector(randomUnitVector(), Math.sin(i * 2.7 + this.seed) * 0.035 * taper);
    }

    const geometry = new THREE.BufferGeometry().setFromPoints(points);
    const material = new THREE.LineBasicMaterial({
      color: Math.random() > 0.25 ? 0xffe8aa : 0xfff7d8,
      transparent: true,
      opacity: this.baseOpacity,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.line = new THREE.Line(geometry, material);
    worldGroup.add(this.line);
  }

  update(dt) {
    this.age += dt;
    const pulse = 0.82 + Math.sin(elapsed * 1.3 + this.seed) * 0.18;
    const sourceEnergy = Math.min(1.9, 0.65 + this.sourceNode.strength * 0.055);
    this.line.material.opacity = Math.min(0.34, this.baseOpacity * pulse * sourceEnergy);
  }

  dispose() {
    worldGroup.remove(this.line);
    this.line.geometry.dispose();
    this.line.material.dispose();
  }
}

function outsideDistance(position) {
  return Math.max(
    0,
    Math.abs(position.x) - HALF.x,
    Math.abs(position.y) - HALF.y,
    Math.abs(position.z) - HALF.z,
  );
}

function computeStrokeForce(stroke) {
  const force = new THREE.Vector3();
  const collective = 1 + Math.log1p(system.strokes.length) * 0.34;

  for (const other of system.strokes) {
    if (other === stroke || !other.active) continue;
    const delta = tempV1.copy(other.position).sub(stroke.position);
    const d2 = delta.lengthSq();
    if (d2 < 0.05 || d2 > 150) continue;
    const d = Math.sqrt(d2);

    if (d < 0.72) {
      force.addScaledVector(delta.normalize(), -0.09 * (0.72 - d));
    } else {
      const pull = SETTINGS.lineAttraction * collective / (1 + d * 0.72);
      force.addScaledVector(delta.normalize(), pull);
    }
  }

  for (const node of system.nodes) {
    const delta = tempV2.copy(node.position).sub(stroke.position);
    const d2 = delta.lengthSq();
    if (d2 < 0.08 || d2 > 260) continue;
    const d = Math.sqrt(d2);
    const pull = SETTINGS.nodeAttraction * (0.7 + node.strength * 0.12) / (1 + d * d * 0.18);
    force.addScaledVector(delta.normalize(), Math.min(0.36, pull));
  }

  return force.clampLength(0, 0.48);
}

function hashCoord(value) {
  return Math.floor(value / HASH_CELL);
}

function hashKey(x, y, z) {
  return `${x},${y},${z}`;
}

function segmentCellRange(a, b) {
  return {
    minX: hashCoord(Math.min(a.x, b.x) - SETTINGS.intersectionDistance),
    maxX: hashCoord(Math.max(a.x, b.x) + SETTINGS.intersectionDistance),
    minY: hashCoord(Math.min(a.y, b.y) - SETTINGS.intersectionDistance),
    maxY: hashCoord(Math.max(a.y, b.y) + SETTINGS.intersectionDistance),
    minZ: hashCoord(Math.min(a.z, b.z) - SETTINGS.intersectionDistance),
    maxZ: hashCoord(Math.max(a.z, b.z) + SETTINGS.intersectionDistance),
  };
}

function registerSegment(stroke, a, b, detect = true) {
  const segment = { strokeId: stroke.id, a: a.clone(), b: b.clone() };
  const range = segmentCellRange(a, b);
  const candidates = new Set();

  for (let x = range.minX; x <= range.maxX; x += 1) {
    for (let y = range.minY; y <= range.maxY; y += 1) {
      for (let z = range.minZ; z <= range.maxZ; z += 1) {
        const key = hashKey(x, y, z);
        const bucket = system.segmentHash.get(key);
        if (detect && bucket) bucket.forEach((candidate) => candidates.add(candidate));
      }
    }
  }

  if (detect) {
    for (const candidate of candidates) {
      if (candidate.strokeId === stroke.id || !system.strokeMap.has(candidate.strokeId)) continue;
      const directionA = tempV3.copy(b).sub(a).normalize();
      const directionB = tempV4.copy(candidate.b).sub(candidate.a).normalize();
      const crossingAngle = 1 - Math.abs(directionA.dot(directionB));
      if (crossingAngle < 0.08) continue;

      const result = closestPointsOnSegments(a, b, candidate.a, candidate.b);
      if (result.distance < SETTINGS.intersectionDistance) {
        const energy = 0.22 + crossingAngle * 0.5 + system.strokes.length * 0.003;
        createOrStrengthenNode(result.pointA.clone().lerp(result.pointB, 0.5), energy);
      }
    }
  }

  for (let x = range.minX; x <= range.maxX; x += 1) {
    for (let y = range.minY; y <= range.maxY; y += 1) {
      for (let z = range.minZ; z <= range.maxZ; z += 1) {
        const key = hashKey(x, y, z);
        if (!system.segmentHash.has(key)) system.segmentHash.set(key, []);
        system.segmentHash.get(key).push(segment);
      }
    }
  }
  system.segmentCount += 1;
}

function closestPointsOnSegments(p1, q1, p2, q2) {
  const d1 = q1.clone().sub(p1);
  const d2 = q2.clone().sub(p2);
  const r = p1.clone().sub(p2);
  const a = d1.dot(d1);
  const e = d2.dot(d2);
  const f = d2.dot(r);
  let s;
  let t;

  if (a <= 1e-8 && e <= 1e-8) {
    return { distance: p1.distanceTo(p2), pointA: p1.clone(), pointB: p2.clone() };
  }

  if (a <= 1e-8) {
    s = 0;
    t = THREE.MathUtils.clamp(f / e, 0, 1);
  } else {
    const c = d1.dot(r);
    if (e <= 1e-8) {
      t = 0;
      s = THREE.MathUtils.clamp(-c / a, 0, 1);
    } else {
      const b = d1.dot(d2);
      const denominator = a * e - b * b;
      s = denominator !== 0 ? THREE.MathUtils.clamp((b * f - c * e) / denominator, 0, 1) : 0;
      t = (b * s + f) / e;
      if (t < 0) {
        t = 0;
        s = THREE.MathUtils.clamp(-c / a, 0, 1);
      } else if (t > 1) {
        t = 1;
        s = THREE.MathUtils.clamp((b - c) / a, 0, 1);
      }
    }
  }

  const pointA = p1.clone().addScaledVector(d1, s);
  const pointB = p2.clone().addScaledVector(d2, t);
  return { distance: pointA.distanceTo(pointB), pointA, pointB };
}

function createOrStrengthenNode(position, energy) {
  let closest = null;
  let closestDistance = Infinity;

  for (const node of system.nodes) {
    const distance = node.position.distanceTo(position);
    if (distance < closestDistance) {
      closest = node;
      closestDistance = distance;
    }
  }

  const mergeRadius = 0.62 + Math.min(0.65, system.nodes.length * 0.007);
  if (closest && closestDistance < mergeRadius) {
    closest.absorb(energy);
    closest.position.lerp(position, 0.035);
    closest.group.position.copy(closest.position);
  } else if (system.nodes.length < 90) {
    const node = new CoreNode(position);
    node.absorb(energy);
    system.nodes.push(node);
  }
}

function pickFilamentTarget(node) {
  const nearbyNodes = system.nodes
    .filter((other) => other !== node)
    .map((other) => ({ point: other.position, distance: other.position.distanceTo(node.position) }))
    .filter((entry) => entry.distance > 0.8 && entry.distance < 10)
    .sort((a, b) => a.distance - b.distance);

  if (nearbyNodes.length && Math.random() < 0.42) {
    return nearbyNodes[Math.floor(Math.random() * Math.min(4, nearbyNodes.length))].point.clone();
  }

  const candidates = [];
  for (const stroke of system.strokes) {
    for (let i = 3; i < stroke.points.length; i += 7) {
      const point = stroke.points[i];
      const distance = point.distanceTo(node.position);
      if (distance > 0.55 && distance < 7.5) candidates.push({ point, distance });
    }
  }

  if (candidates.length) {
    candidates.sort((a, b) => a.distance - b.distance);
    const pool = candidates.slice(0, Math.min(18, candidates.length));
    return pool[Math.floor(Math.random() * pool.length)].point.clone();
  }

  return node.position.clone().add(randomUnitVector().multiplyScalar(rand(0.8, 2.6 + node.strength * 0.08)));
}

function growFilamentFrom(node) {
  if (system.filaments.length >= 460) return;
  const target = pickFilamentTarget(node);
  const filament = new Filament(node, target);
  system.filaments.push(filament);

  if (node.strength > 5 && Math.random() < 0.18 && system.filaments.length < 460) {
    const branchPoint = node.position.clone().lerp(target, rand(0.3, 0.72));
    const branchTarget = branchPoint.clone().add(randomUnitVector().multiplyScalar(rand(0.45, 1.6)));
    system.filaments.push(new Filament(node, branchTarget));
  }
}

function spawnStroke() {
  const stroke = new OrganicStroke();
  system.strokes.push(stroke);
  system.strokeMap.set(stroke.id, stroke);

  while (system.strokes.length > SETTINGS.maxLines) {
    const old = system.strokes.shift();
    system.strokeMap.delete(old.id);
    old.dispose();
  }
}

function rebuildSegmentHash() {
  system.segmentHash.clear();
  system.segmentCount = 0;
  for (const stroke of system.strokes) {
    for (let i = 1; i < stroke.points.length; i += 1) {
      registerSegment(stroke, stroke.points[i - 1], stroke.points[i], false);
    }
  }
  system.lastHashRebuild = elapsed;
}

function updateSystem(dt) {
  spawnAccumulator += dt;
  if (SETTINGS.autoSpawn && spawnAccumulator >= SETTINGS.spawnInterval) {
    spawnAccumulator %= SETTINGS.spawnInterval;
    spawnStroke();
  }

  for (const stroke of system.strokes) stroke.update(dt);
  for (const node of system.nodes) node.update(dt);
  for (const filament of system.filaments) filament.update(dt);

  const fullyExpired = system.strokes.filter((stroke) => stroke.expired);
  if (fullyExpired.length) {
    for (const stroke of fullyExpired) {
      stroke.dispose();
      system.strokeMap.delete(stroke.id);
    }
    system.strokes = system.strokes.filter((stroke) => !stroke.expired);
  }

  if (elapsed - system.lastHashRebuild > 14 || system.segmentCount > 28000) {
    rebuildSegmentHash();
  }
}

function resetSystem() {
  resetTimers.forEach((timer) => window.clearTimeout(timer));
  resetTimers = [];
  for (const stroke of system.strokes) stroke.dispose();
  for (const node of system.nodes) node.dispose();
  for (const filament of system.filaments) filament.dispose();
  system.strokes = [];
  system.strokeMap.clear();
  system.nodes = [];
  system.filaments = [];
  system.segmentHash.clear();
  system.segmentCount = 0;
  system.lastHashRebuild = elapsed;
  spawnAccumulator = 0;

  for (let i = 0; i < 5; i += 1) {
    const timer = window.setTimeout(() => spawnStroke(), i * 115);
    resetTimers.push(timer);
  }
}

function updateStats() {
  document.querySelector('#lineCount').textContent = `${system.strokes.length} streker`;
  document.querySelector('#nodeCount').textContent = `${system.nodes.length} kjerner`;
  document.querySelector('#filamentCount').textContent = `${system.filaments.length} tråder`;
}

function bindControls() {
  document.querySelectorAll('[data-setting]').forEach((input) => {
    const key = input.dataset.setting;
    const output = document.querySelector(`output[for="${input.id}"]`);

    const apply = () => {
      const value = Number(input.value);
      SETTINGS[key] = key === 'maxLines' ? Math.round(value) : value;
      if (key === 'spawnInterval') output.value = `${value.toFixed(1)}s`;
      else if (key === 'maxLines') output.value = String(Math.round(value));
      else output.value = value < 1 ? value.toFixed(2) : value.toFixed(1);

      if (key === 'maxLines') {
        while (system.strokes.length > SETTINGS.maxLines) {
          const old = system.strokes.shift();
          system.strokeMap.delete(old.id);
          old.dispose();
        }
      }
    };

    input.addEventListener('input', apply);
    apply();
  });

  const autoSpawn = document.querySelector('#autoSpawn');
  autoSpawn.addEventListener('change', () => { SETTINGS.autoSpawn = autoSpawn.checked; });

  const showFields = document.querySelector('#showFields');
  showFields.addEventListener('change', () => {
    SETTINGS.showFields = showFields.checked;
    system.strokes.forEach((stroke) => stroke.updateVisualStrength());
  });

  document.querySelector('#newLine').addEventListener('click', spawnStroke);
  document.querySelector('#pause').addEventListener('click', togglePause);
  document.querySelector('#reset').addEventListener('click', resetSystem);
}

function togglePause() {
  paused = !paused;
  document.querySelector('#pause').textContent = paused ? 'Fortsett' : 'Pause';
}

function onKeyDown(event) {
  if (event.target instanceof HTMLInputElement || event.target instanceof HTMLButtonElement) return;
  const key = event.key.toLowerCase();
  if (key === ' ' || key === 'n') {
    event.preventDefault();
    spawnStroke();
  } else if (key === 'p') {
    togglePause();
  } else if (key === 'r') {
    resetSystem();
  } else if (key === 'f') {
    SETTINGS.showFields = !SETTINGS.showFields;
    document.querySelector('#showFields').checked = SETTINGS.showFields;
    system.strokes.forEach((stroke) => stroke.updateVisualStrength());
  } else if (key === 'h') {
    panel.classList.toggle('hidden');
  }
}

function onResize() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(width, height, false);
  lineMaterials.forEach((material) => material.resolution.set(width, height));
}

const clock = new THREE.Clock();
function animate() {
  requestAnimationFrame(animate);
  const rawDt = clock.getDelta();
  const dt = Math.min(rawDt, 0.045);
  frame += 1;

  if (!paused) {
    elapsed += dt;
    updateSystem(dt);
  }

  controls.update();
  renderer.render(scene, camera);

  if (elapsed - lastStatsUpdate > 0.25) {
    updateStats();
    lastStatsUpdate = elapsed;
  }
}

addWorldFrame();
addAmbientDust();
bindControls();
window.addEventListener('resize', onResize);
window.addEventListener('keydown', onKeyDown);
onResize();
resetSystem();
animate();
