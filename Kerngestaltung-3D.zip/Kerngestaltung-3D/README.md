# Kerngestaltung 3D

Et nettleserbasert, generativt 3D-verk der organiske kullstreker beveger seg gjennom et avgrenset rom. Strekene påvirker hverandre gjennom svake felt. Når to spor møtes, oppstår en magnetisk kjerne som både trekker nye streker til seg og bygger et mycel-lignende lysvev rundt møtepunktet.

Prosjektet er laget som en enkel statisk nettside og kan publiseres direkte med **GitHub Pages**. Ingen bygging eller installasjon er nødvendig.

## Åpne lokalt

En modulbasert Three.js-side bør åpnes gjennom en lokal webserver, ikke ved å dobbeltklikke på `index.html`.

```bash
python -m http.server 8000
```

Åpne deretter:

```text
http://localhost:8000
```

## Publisere på GitHub Pages

1. Opprett et offentlig repository, for eksempel `kerngestaltung-3d`.
2. Last opp `index.html` og `main.js` til rotmappen.
3. Åpne **Settings → Pages**.
4. Velg **Deploy from a branch**, deretter `main` og `/root`.
5. GitHub viser nettadressen når siden er publisert.

## Styring

- Dra med musen: roter rommet
- Musehjul: flytt kamera inn/ut
- Høyreklikk og dra: forskyv visningen
- `N` eller mellomrom: generer en ny strek
- `P`: pause / fortsett
- `F`: vis / skjul feltglorier
- `H`: vis / skjul kontrollpanelet
- `R`: nullstill verket

## Hvordan systemet virker

### 1. Den levende streken

Hver strek starter med to tilfeldige punkter: et startpunkt og et foreløpig målpunkt. Den går ikke rett mellom dem. Et bevegelig strekhode påvirkes av:

- treghet og hastighet
- et kontinuerlig tredimensjonalt strømningsfelt
- svak tiltrekning mot andre aktive streker
- sterkere tiltrekning mot etablerte kjerner
- en ny tilfeldig målretning når det gamle målet nås

Sporene tegnes som flere nesten sammenfallende linjer med små avvik og spredte kullpartikler. Dette gjør kanten ujevn og mindre datagrafisk.

### 2. Feltet rundt strekene

Alle aktive streker påvirker hverandre svakt. Samlet feltstyrke øker logaritmisk med antall streker, slik at verket fortettes uten at alle linjer umiddelbart kollapser i samme punkt. En bred, svært svak lyslinje viser feltets omtrentlige utstrekning.

### 3. Møtepunkter og kjerner

Nye streksegmenter kontrolleres mot eksisterende segmenter i et tredimensjonalt romgitter. Når avstanden er mindre enn den valgte møteavstanden, oppstår en kjerne. Gjentatte møter i samme område styrker den eksisterende kjernen i stedet for å skape mange nesten identiske punkter.

### 4. Mycel og kokon

En kjerne utvikler:

- et pulserende sentrallys
- håndujevne, roterende løkker som danner en lokal kokon
- lysfilamenter mot nærliggende streker og andre kjerner
- flere og sterkere forbindelser når kjernens styrke og det samlede antallet streker øker

### 5. Romgrensen

Streker kan passere rammen. Når de kommer utenfor, mister de gradvis opasitet og får en svak drift videre ut av rommet. De forsvinner derfor som et fysisk spor som faller ut av synsfeltet, ikke som en brå digital avklipping.

## Parametere som er viktige for organisk utvikling

De mest avgjørende er allerede lagt inn i kontrollpanelet:

- **Strekhastighet**: hvor fort strekhodet beveger seg
- **Intervall**: tiden mellom nye streker
- **Organisk uro**: styrken i det tredimensjonale strømningsfeltet
- **Strekfelt**: gjensidig tiltrekning mellom aktive streker
- **Kjernefelt**: tiltrekning mot etablerte møtepunkter
- **Møteavstand**: hvor nær to segmenter må komme før en kjerne dannes
- **Vevvekst**: hvor raskt kokoner og filamenter utvikles
- **Maks. streker**: ytelses- og tetthetsgrense

## Anbefalte startområder

Et balansert, langsomt voksende verk:

```text
Hastighet:       0.8–1.4
Intervall:       2.0–4.5 s
Organisk uro:    0.6–1.1
Strekfelt:       0.025–0.065
Kjernefelt:      0.08–0.18
Møteavstand:     0.30–0.50
Vevvekst:        0.55–1.10
```

Et tettere og mer selvorganiserende verk kan bruke sterkere felt, men høye verdier for både strekfelt og kjernefelt samtidig vil lett skape én dominerende klump.

## Videre muligheter

Strukturen er forberedt for senere utvidelser som:

- lagring og gjenåpning av en bestemt utvikling
- deterministisk frøverdi for gjentakbare verk
- eksport av stillbilde eller høyoppløselig sekvens
- lydpåvirkning av feltstyrke eller veksthastighet
- flere materialmodi, for eksempel grafitt, sot, kritt eller blekk
- feltvisualisering som faktiske isoflater i stedet for bare glorier

## Teknologi

- Three.js `0.185.0`
- ES-moduler via import map
- Ingen rammeverk og ingen byggetrinn
- Beregning av møter med spatial hashing for å unngå full sammenligning av alle segmenter

## Lisens

MIT. Se `LICENSE`.
